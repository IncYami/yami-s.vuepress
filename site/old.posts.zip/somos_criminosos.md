---
title: SOMOS CRIMINOSOS?!
description: NÃO PODE ROUBAR LEGENDA DE ANIME """""PIRATA""""" !!!!!
display: home
image: /img/meme.png
date: 2022-06-21
tags:
  - meme
categories:
  - meme
---

Pleno 2022 e tem gente chorando na internet sobre pirataria. SIM! PIRATARIA NA INTERNET

Hoje eu recebi algumas mensagens no meu PV do Discord de algum macaco que estava literalmente chorando que a Yami Studio reutiliza legendas de outros Fansubs em alguns animes lançado por aqui... Pse, eu nem sei o que dizer sobre uma macacada dessas, eu queria muito ter tirado print da conversa e deixado fixado por aqui pra todo mundo ver, mas o primata excluiu as mensagens e a própria conta depois que eu respondi ele, já recebi outras mensagens desses seres irracionais tanto por aqui no site quanto no Discord, nunca dei atenção e sempre excluía as mensagens do Disqus por ser algo tão sem noção, mas dessa vez foi diferente, por algum motivo o primata estava com raiva, muita raiva por a gente usar as legendas de certos grupos mortos por aí onde não se encontrava com uma qualidade boa, e desde o começo eu deixei avisado que o foco daqui é lançar os animes em uma qualidade decente de vídeo e áudio e algumas vezes nós estaríamos traduzindo outros animes ou utilizando legendas da CR e por esse motivo e talvez algum outro (?!) sempre foi alvo de macacos irracionais que acha que pirataria no Brasil tem propriedade intelectual, se alguém traduziu e lançou o anime na Fansub X, pertence a ela e ninguém mais pode fazer, vemos isso também no padrão que é usado nas legendas: HARDSUB em pleno 2022 em alguns "grupos" que tem por aí com a desculpa de que sites online roubam a legenda (?!) uma desculpa que não faz sentido nenhum, acha mesmo que sites online está preocupado com o lixo da sua legenda? Pse, não está, só querem upar o mais rápido possível para atrair usuários e eles ganharem dinheiro com propaganda ou VIP e se você deixar em Hardsub é melhor ainda porque eles só precisam upar no servidor deles sem reencodar, uma desculpa que não tem sentido e é completamente irracional...

Mas o que isso tem haver com o macaco raivoso? Bom, muito provável que este ser faz parte de algum Fansub ou algo do tipo ou é só um hater na internet mesmo e quero esclarecer certas coisas que já deveriam estar esclarecido para todos os seres racionais e irracionais: 

#### Legenda inexistente = Legenda perfeita!
Legenda decente não existe! Se quer legenda 100% perfeita, vá aprender japonês e assista sem legenda seus animes de romance isekai sonhando que um dia vai acontecer com você.

#### Gringos X Bananalandia
Se a gente for ver os gringos no nyaa.si vemos grupos como: sam, Vodes, Lulu, OZR, MTBB, Kaleido e principalmente a falecida Coalgirls, todos eles fazem a mesma coisa que a gente, pegam legendas de outros grupos e fazem o próprio lançamento com qualidade distintas de vídeo e áudio e alguns chegam até a editar a legenda.

Já aqui na Bananalandia nós estamos vivendo a uns 15 anos atrás ainda, "Fansubs" cheios de frescuras inúteis como logo do grupo nas aberturas pra todo mundo ver quem foi os macacos que fizeram a legenda e que se utilizam de Hardsub em TS e músicas, uma verdadeira macaquice. Agora, quantos grupos existem aqui que fazem a mesma coisa que a gente? Talvez só a Seicher, somente 2 grupos existentes no Brasil que surgiu com essa ideia de prover legendas de antigas Fansubs em RAWs/Encode melhores, já vemos o quão atrasados somos nesse quesito, eu chamo isso de: Síndrome de Macaco.

![](/img/macaco.jpg)

#### Futuro
Já faz um tempo que quero falar sobre o que vai acontecer ao site, talvez num futuro próximo tudo isso acaba, e não tem nada haver com os macacos raivosos da internet, mas sim porque isso da um certo trabalho de manter principalmente o servidor de arquivos, mês que vem a Google vai encerrar todos os Drives ilimitados que existem por aí e o nosso servidor pode ser um deles e caso isso aconteça eu não terei saco pra ficar buscando alternativas e todos os projetos lançados e futuros se tornarão privados, compartilho os projetos daqui e até outros projetos que não foram lançados no site em um grupo privado de arquivamento, então caso aconteça e eu não achar uma alternativa fácil para o Drive, basicamente será o fim.

Bom, escrevi bastante coisa e espero ter esclarecido o BÁSICO para alguns que não entenderam ainda e um rápido recado para os macacos raivosos: vai tomar no cu.

![](/img/qi.webp)
![](/img/meme.px.png)

<br><hr><br>
<Disqus/>
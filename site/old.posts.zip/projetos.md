---
title: Projetos Atualizados
display: home
image: https://images4.alphacoders.com/126/1264528.png
date: 2024-08-31
tags:
  - Projetos
categories:
  - Anime
---

Alguns projetos serão atualizados com novas raws/encode e melhorias/padronização nas legendas e no muxing dos arquivos com tags corretas para uma melhor visualização nos players de vídeo, por aqui, serão listados os projetos relançados.

Todos os projetos estão disponíveis para download em [cloud.yami-s.com](https://cloud.yami-s.com/0:/), link direto para a pasta do projeto específico está no nome do mesmo.

## [Overlord](https://cloud.yami-s.com/0:/Overlord/)
- Overlord
- Overlord II
- Overlord III
- Overlord IV

Foi feito padronização nas legendas e novo muxing.




<br><hr><br>
<Disqus/>
